





//http://localhost:8081/poc2?xyz=3

const connection = mysql.createConnection ( {
    host: 'localhost',
    user: 'root',
    password: 'cdac',
    database: 'kolhapur',
	port:3306
});

const mysql = require('mysql2');

const express = require('express');
const app = express();

const cors = require('cors');
app.use(cors());


const bodyParser = require('body-parser');
const { response } = require('express');






app.use(express.static('abc'));
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true }));
//whether you want nested objects support  or not



var result;

app.post('/poc1', function (req, res) {
	
		console.log("reading input " + req.body.v1 +  "  second " + req.body.v2)

		
    	var xyz ={ v1:37, v2:35};
        res.send(xyz);
    });

	
	
	



app.get('/poc2', function (req, res) {
    
	
        console.log("reading input " + req.query.xyz);
		
    	var xyz ={ v1:37, v2:35};

		res.send(xyz);

		});

		
		connection.query('update book set bookid = ? , bookname = ? where price = ?', 
		[req.body.inp3, req.body.inp2, req.query.body.inp3],
		 (err, res1) => {
			if (err) {
				result = err;
				
			} else {
				result = {
					concept: "so what",
					rws: res1.affectedRows
				};
				
			}
				
			res.send(result);
		});
		
	





app.listen(8081, function () {
    console.log("server listening at port 8081...");
});